
module.exports = function(bot) {
    // Modify bot here
    // bot.config // Rhythm-Bot Config object
    // bot.client // discord.js client
    // bot.queue // Music Queue
    //console.log(bot);
};
